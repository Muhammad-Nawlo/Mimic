<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Interesting;
use Faker\Generator as Faker;

$factory->define(Interesting::class, function (Faker $faker) {
    return [
        //
    ];
});
